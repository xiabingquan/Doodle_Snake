#ifndef __KEY_H__
#define __KEY_H__
unsigned char OSScanKey(void);
//unsigned char OSReadKey(void);
void delayKey(unsigned int);
#endif
