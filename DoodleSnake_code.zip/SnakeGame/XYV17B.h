#ifndef _XYV17B_H_
#define _XYV17B_H_
void uart_tx_command(unsigned int);
void game_start();
void game_win();
void game_lose();
void speed_up();
void speed_down();
void good_job();
#endif
